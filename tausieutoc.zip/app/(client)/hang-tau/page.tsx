import Shipbrand from "@components/client/Shipbrand/Shipbrand";
import React from "react";

const ShipbrandPage = () => {
  return (
    <div>
      <Shipbrand />
    </div>
  );
};

export default ShipbrandPage;

export const OtherServiceItems = [
  {
    title: "Quầy minibar",
    content: "Phục vụ thức ăn nhẹ và nước giải khát trên tàu",
    image:
      "https://superdong.com.vn/wp-content/uploads/2019/04/fast-ferry-superdong-5-390x390.png",
  },
  {
    title: "Ghế nằm Phan Thiết <=> Phú Quý",
    content:
      "Đáp ứng nhu cầu bà con trong chuyến hành trình từ Phan Thiết đi Phú Quý và ngược lại nhiều trải nghiệm thú vị và tiện ích",
    image:
      "https://superdong.com.vn/wp-content/uploads/2019/03/noi-that-tau-superdong-phu-quy-2-g-390x390.png",
  },
  {
    title: "Ghế massage",
    content:
      "Phục vụ trên phà tuyến Hà Tiên <=> Phú Quốc. Giá: 10 phút = 10.000 đ",
    image:
      "https://superdong.com.vn/wp-content/uploads/2019/04/noi-that-pha-390x390.png",
  },
  {
    title: "Khu vực ăn uống nhẹ trên phà",
    content: "Phục vụ trên tuyến phà Hà Tiên <=> Phú Quốc",
    image:
      "https://superdong.com.vn/wp-content/uploads/2019/04/fast-ferry-superdong-2-390x390.png",
  },
  {
    title: "Khoang ngắm cảnh",
    content: "Phù hợp cho các bạn trẻ yêu thích chụp ảnh",
    image:
      "https://superdong.com.vn/wp-content/uploads/2019/04/fast-ferry-superdong-4-390x390.png",
  },
  {
    title: "Quầy minibar",
    content: "Phục vụ thức ăn nhẹ và nước giải khát trên tàu",
    image:
      "https://superdong.com.vn/wp-content/uploads/2019/04/fast-ferry-superdong-5-390x390.png",
  },
];
